﻿using System;

namespace CaesarCipherLibrary
{
    public class CaesarBase
    {
        protected int Key { get; set; }

        private char Chiper(char ch)
        {

        }
    }
}
